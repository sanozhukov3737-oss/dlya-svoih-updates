@echo off
call "%~dp0tools\CHECK_PHONE.cmd" --out "%~dp0results"
